var app = angular.module('myApp', ['ngRoute']);

app.controller('myCtrl', ['$scope', '$http', function($scope, $http)
{
    $http.get("../test.json").then(function (response) {
        $scope.logo = response.data.Logo;
        //console.log($scope.logo);
    });
}]);